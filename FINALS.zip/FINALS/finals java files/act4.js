function compute() {
    let mid = document.getElementById('mid').value;
    let fin = document.getElementById('fin').value;
    let average = (Number(mid) + Number(fin)) / 2;    
  
    let remark = '';
  
    if (average >= 100) remark = "1.0";
    else if (average >= 98) remark = "1.1";
    else if (average >= 96) remark = "1.2";
    else if (average >= 93) remark = "1.3";
    else if (average >= 90) remark = "1.4";
    else if (average >= 88) remark = "1.6";
    else if (average >= 87) remark = "1.8";
    else if (average >= 86) remark = "1.9";
    else if (average >= 85) remark = "2.0";
    else if (average >= 84) remark = "2.1";
    else if (average >= 83) remark = "2.2";
    else if (average >= 82) remark = "2.3";
    else if (average >= 81) remark = "2.4";
    else if (average >= 80) remark = "2.5";
    else if (average >= 79) remark = "2.6";
    else if (average >= 78) remark = "2.7";
    else if (average >= 77) remark = "2.8";
    else if (average >= 76) remark = "2.9";
    else if (average >= 70) remark = "3.0";
    else remark = "5.0 (Failed)";
  
    document.getElementById('fg').textContent = average.toFixed(2);
    document.getElementById('remarks').textContent = remark;
}



function clearFields() {
    document.getElementById('stdName').value = '';
    document.getElementById('stdNo').value = '';
    document.getElementById('mid').value = '';
    document.getElementById('fin').value = '';
    document.getElementById('fg').textContent = '';
    document.getElementById('remarks').textContent = '';
}

if (average >= 70) {
    alert("🎉 Congratulations! You passed!");
}
  