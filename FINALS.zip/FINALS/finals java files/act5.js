function toggleZoom(element) {
    element.classList.toggle("zoomed");
  }
