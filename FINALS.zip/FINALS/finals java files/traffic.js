let currentLight = "green"; // Start with green light on

function changeLight() {
  // Turn off all lights first (remove glowing)
  document.getElementById("red").classList.remove("on");
  document.getElementById("yellow").classList.remove("on");
  document.getElementById("green").classList.remove("on");

  // Switch lights and apply glow effect
  if (currentLight === "green") {
    document.getElementById("yellow").classList.add("on");
    currentLight = "yellow";
    setTimeout(changeLight, 7000); // 7 seconds for yellow
  } else if (currentLight === "yellow") {
    document.getElementById("red").classList.add("on");
    currentLight = "red";
    setTimeout(changeLight, 9000); // 9 seconds for red
  } else {
    document.getElementById("green").classList.add("on");
    currentLight = "green";
    setTimeout(changeLight, 7000); // 7 seconds for green
  }
}

// Start the light cycle
changeLight();
