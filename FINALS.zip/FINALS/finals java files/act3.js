function toggleDropdown() {
    const dropdown = document.querySelector('.dropdown');
    dropdown.classList.toggle('show');
  
    const arrow = document.getElementById('arrow');
    arrow.classList.toggle('rotate');
  
    // Change arrow symbol
    arrow.innerText = arrow.classList.contains('rotate') ? '▼' : '▲';
  }
  
  function loadIframe(filePath) {
    document.getElementById('contentFrame').src = filePath;
  
    // Close dropdown after clicking
    document.querySelector('.dropdown').classList.remove('show');
    const arrow = document.getElementById('arrow');
    arrow.classList.remove('rotate');
    arrow.innerText = '▼';
  }
  
  window.onclick = function (e) {
    if (!e.target.closest('.dropdown')) {
      document.querySelector('.dropdown')?.classList.remove('show');
      const arrow = document.getElementById('arrow');
      arrow?.classList.remove('rotate');
      arrow.innerText = '▼';
    }
  };
  